﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem2
{
    //Preemptive
    public class RR
    {
        // Method to find the waiting time
        // for all processes
        static void findWaitingTime(Process[] proc,
             int n, int[] wt, int[] service_time)
        {
            int quantum = 3;

            // Make a copy of burst times bt[] to 
            // store remaining burst times.
            int[] rem_bt = new int[n];

            for (int i = 0; i < n; i++)
                rem_bt[i] = proc[i].bt;

            int t = 0; // Current time

            while (true)
            {
                bool done = true;
                for (int i = 0; i < n; i++)
                {
                    if (rem_bt[i] > 0)
                    {
                        done = false;

                        if (rem_bt[i] > quantum)
                        {
                            t += quantum;
                            rem_bt[i] -= quantum;
                        }
                        else
                        {
                            t = t + rem_bt[i];
                            service_time[i] = t;
                            wt[i] = t - proc[i].bt - proc[i].art;
                            rem_bt[i] = 0;
                        }
                    }
                }
                if (done == true)
                    break;
            }
        }

        //print
        public void findavgTime(Process[] proc, int n)
        {
            int[] wt = new int[n]; int[] service_time = new int[n];
            int total_wt = 0, service_time1 = 0;

            // Function to find waiting time of all
            // processes
            findWaitingTime(proc, n, wt, service_time);

            // Display processes along with all
            // details
            Console.WriteLine("Processes " +
                            "\tArrival time " +
                            "\tBurst time " +
                            "\tService time " +
                            "\tPriority " +
                            "\tWait time");

            // Calculate total waiting time and
            // total turnaround time
            for (int i = 0; i < n; i++)
            {
                //tat = wt
                //serv = wait - art
                total_wt += wt[i];
                service_time1 = wt[i] + proc[i].art + proc[i].bt;
                Console.WriteLine(" " + proc[i].pid + "\t\t"
                                + proc[i].art + "\t\t " + proc[i].bt + "\t\t" + service_time1 + "\t\t " + proc[i].p
                                + "\t\t" + wt[i]);
            }
            Console.WriteLine("Total wait time = " +
                            total_wt);
            Console.WriteLine("Average waiting time = " +
                            (float)total_wt / (float)n);
        }
    }
}
