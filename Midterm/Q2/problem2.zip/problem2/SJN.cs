﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem2
{
    public class SJN
    {
        public void findavgTime(Process[] proc, int n)
        {
            int[] wt = new int[n];
            //sorting of priority times
            int i = 0;
            int j = 0;
            Process temp = new Process(0, 0, 0, 0); //temp var
            int pos = 0;
            for (i = 0; i < n; i++)
            {
                pos = i;
                for (j = i + 1; j < n; j++)
                {
                    if (proc[j].bt < proc[pos].bt)
                        pos = j;
                }
                //sorting
                temp = proc[i];
                proc[i] = proc[pos];
                proc[pos] = temp;
            }
            FCFS myFCFS = new FCFS();
            myFCFS.findavgTime(proc, proc.Length);

        }
    }
}
