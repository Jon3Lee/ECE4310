﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem2
{
    public class priorityScheduling
    {
        public void findWaitingTime(Process[] proc, int n, int[] wt, int[] service_time)
        {
            //sorting of priority times
            int i = 0;
            int j = 0;
            Process temp = new Process(0, 0, 0, 0); //temp var
            int pos = 0;
            for (i = 0; i < n; i++)
            {
                pos = i;
                for (j = i + 1; j < n; j++)
                {
                    if (proc[j].p < proc[pos].p)
                        pos = j;
                }
                //sorting
                temp = proc[i];
                proc[i] = proc[pos];
                proc[pos] = temp;
            }
            service_time[0] = 0;
            wt[0] = 0;

            // calculating waiting time
            for (i = 1; i < n; i++)
            {
                service_time[i] = service_time[i - 1] + proc[i - 1].bt;
                wt[i] = service_time[i] - proc[i].art;

                if (wt[i] < 0)
                    wt[i] = 0;
            }

        }
        
        //print
        public void findavgTime(Process[] proc, int n)
        {
            int[] wt = new int[n]; int[] service_time = new int[n];
            int total_wt = 0;

            findWaitingTime(proc, n, wt, service_time);

            Console.WriteLine("Processes " +
                            "\tArrival time " +
                            "\tBurst time " +
                            "\tService time " +
                            "\tPriority " +
                            "\tWait time");

            for (int i = 0; i < n; i++)
            {
                total_wt += wt[i];
                Console.WriteLine(" " + proc[i].pid + "\t\t"
                                + proc[i].art + "\t\t " + proc[i].bt + "\t\t" + service_time[i] + "\t\t " + proc[i].p
                                + "\t\t" + wt[i]);
            }
            Console.WriteLine("Total wait time = " +
                            total_wt);
            Console.WriteLine("Average waiting time = " +
                            (float)total_wt / (float)n);
        }
    }
}
