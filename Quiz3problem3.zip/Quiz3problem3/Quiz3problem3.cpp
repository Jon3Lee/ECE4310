// Quiz3problem3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    //Ten file declaration
    ofstream file15;
    ofstream file25;
    ofstream file35;
    ofstream file45;
    ofstream file55;
    ofstream file65;
    ofstream file75;
    ofstream file85;
    ofstream file95;
    ofstream file105;

    file15.open("fifteen.txt");
    file15.seekp(14);   //#bytes - 1 since we are adding 1 char byte 'a'
    file15 << 'a';
    file15.close();

    file25.open("twentyfive.txt");
    file25.seekp(24);
    file25 << 'a';
    file25.close();

    file35.open("thirtyfive.txt");
    file35.seekp(34);
    file35 << 'a';
    file35.close();

    file45.open("fortyfive.txt");
    file45.seekp(44);
    file45 << 'a';
    file45.close();

    file55.open("fiftyfive.txt");
    file55.seekp(54);
    file55 << 'a';
    file55.close();

    file65.open("sixtyfive.txt");
    file65.seekp(64);
    file65 << 'a';
    file65.close();

    file75.open("seventyfive.txt");
    file75.seekp(74);
    file75 << 'a';
    file75.close();

    file85.open("eightyfive.txt");
    file85.seekp(84);
    file85 << 'a';
    file85.close();

    file95.open("ninetyfive.txt");
    file95.seekp(94);
    file95 << 'a';
    file95.close();

    file105.open("onehundredfive.txt");
    file105.seekp(104);
    file105 << 'a';
    file105.close();

    cout << "The ten files have been created!" << endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
