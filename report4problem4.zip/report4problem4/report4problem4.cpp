// report4problem4.cpp : This file contains the 'main' function. Program execution begins and ends there.
/*
Do simulations (write computer programs) for a restaurant with n1 = 10 tables, where 
the number of seats in each table ranges from 1 to n2 = 15 seats (i.e. you�ll have a nested loop, 
with the outer loop i = 1 to n1 = 10 looping through the tables, and the inner loop j = 1 to n2 = 15 
looping through the possible number of seats in each table). Assume the number of guest parties 
is n3 = 8, with the size of each party ranging from 1 to n4 = 7.

�	How many possible combinations are run by this simulation?
�	Among these combinations, how many can be satisfied by both first fit and best fit?
�	Among these combinations, how many can be satisfied by first fit only, but not best fit?
�	Among these combinations, how many can be satisfied by best fit only, but not first fit?
�	Among these combinations, how many can be satisfied by neither first fit nor best fit?

*/

#include <iostream>

using namespace std;

void print(int tables_avail[], int allocation[],
    int groups_avail[], int n)
{
    int seated = 0;
    int not_seated = 0;
    cout << endl;
    //print loop
    for (int i = 0; i < n; i++)
    {
        if (allocation[i] >= 0)
        {
            cout << "Table # " << allocation[i] + 1 << ":\tparty of " << groups_avail[i] << "\twith " << tables_avail[allocation[i]] << " seats left at the table"
                << "(group# " << i + 1 << ")" << endl;
            seated++;
        }
        else
        {
            cout << "Group# " << i + 1 << "\twith a party of " << groups_avail[i] << " was Not Allocated!\n";
            not_seated++;
        }
    }
    cout << "\nTotal possible combinations run: " << seated + not_seated << "\tNum of combinations seated: " << seated
        << "\tNum of combinations not seated: " << not_seated << endl << endl;
}
//FFT
void firstFit(int tables_avail[], int m,
    int groups_avail[], int n)
{
    // Stores allocation
    int* allocation = new int[n];
    //setting a temp table since we don't want to overwrite initial tables
    int * temp_tables_avail = new int[m];

    // Initializing arrays
    for (int i = 0; i < n; i++)
        allocation[i] = -1;
    for (int i = 0; i < m; i++)
        temp_tables_avail[i] = tables_avail[i];
    
    //Nested for loop to count through group list then through tables
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (temp_tables_avail[j] >= groups_avail[i])
            {
                // allocate table to party
                allocation[i] = j;

                // Reduce available seats in this table.
                temp_tables_avail[j] -= groups_avail[i];

                break;
            }
        }
    }
    print(temp_tables_avail, allocation,
        groups_avail, n);
}
//BFT
void bestFit(int tables_avail[], int m,
    int groups_avail[], int n)
{
    // Stores allocation
    int* allocation = new int[n];
    //setting a temp table since we don't want to overwrite initial tables
    int* temp_tables_avail = new int[m];

    // Initializing arrays
    for (int i = 0; i < n; i++)
        allocation[i] = -1;
    for (int i = 0; i < m; i++)
        temp_tables_avail[i] = tables_avail[i];

    //Nested for loop to count through group list then through tables
    for (int i = 0; i < n; i++)
    {
        // Find the best fit index for current process
        int bestIdx = -1;
        for (int j = 0; j < m; j++)
        {
            if (temp_tables_avail[j] >= groups_avail[i])
            {
                if (bestIdx == -1)
                    bestIdx = j;
                else if (temp_tables_avail[bestIdx] > temp_tables_avail[j])
                    bestIdx = j;
            }
        }

        // If we could find an best fit index for current party
        if (bestIdx != -1)
        {
            // allocate table to best index
            allocation[i] = bestIdx;

            // Reduce available seats in this table.
            temp_tables_avail[bestIdx] -= groups_avail[i];
        }
    }
    print(temp_tables_avail, allocation,
        groups_avail, n);
}

int main()
{
    cout << "Problem 4:\n";
    int n1 = 100;    //n1 = 10 tables
    int n2 = 150;    //n2 = 15 seats

    int n3 = 80; //num of guest parties. 8 by default
    int n4 = 70; //size of each party from 1 to n4 = 7

    //rand party arr
    int* group = new int[n3];
    for (int i = 0; i < n3; i++)
        group[i] = rand() % n4 + 1;

    //table arr
    int* tables = new int[n1];
    for (int i = 0; i < n1; i++)
        tables[i] = n2;
    /*
    //Part D
    //Q1
    int table[] = { 5, 4, 6, 7 };
    int groups_Q1[] = { 4, 5, 6, 7 };
    int m = sizeof(table) / sizeof(table[0]);
    int n_Q1 = sizeof(groups_Q1) / sizeof(groups_Q1[0]);
    //Q2
    int groups_Q2[] = { 7, 6, 5, 4 };
    int n_Q2 = sizeof(groups_Q2) / sizeof(groups_Q2[0]);
    //Q3
    int groups_Q3[] = { 2, 2, 2, 2, 2, 2 };
    int n_Q3 = sizeof(groups_Q3) / sizeof(groups_Q3[0]);

    cout << "*********************************PartD***********************************\n";
    cout << "*********************************Q1**************************************\n";
    cout << "*********************************Bestfit*********************************";
    bestFit(table, m, groups_Q1, n_Q1);
    cout << "*********************************Firstfit********************************";
    firstFit(table, m, groups_Q1, n_Q1);
    
    cout << "*********************************Q2**************************************\n";
    cout << "*********************************Bestfit*********************************";
    bestFit(table, m, groups_Q2, n_Q2);
    cout << "*********************************Firstfit********************************";
    firstFit(table, m, groups_Q2, n_Q2);
 
    cout << "*********************************Q3**************************************\n";
    cout << "*********************************Bestfit*********************************";
    bestFit(table, m, groups_Q3, n_Q3);
    cout << "*********************************Firstfit********************************";
    firstFit(table, m, groups_Q3, n_Q3);
    */

    
    //Parts C, E, F......by changing values of n1..n4
    cout << "*********************************Bestfit*********************************";
    //bestFit(tables_avail, m, groups_avail, n);
    bestFit(tables, n1, group, n3);
    cout << "*********************************Firstfit********************************";
    //firstFit(tables_avail, m, groups_avail, n);
    firstFit(tables, n1, group, n3);
    

    return 0;

    }